import React from 'react'
import Home from './Pages/Home'

import { BrowserRouter,Routes,Route } from 'react-router-dom'

import Navbar from './Components/Navbar'
import Register from './Pages/Register'
import Registerlist from './Pages/Registerlist'


const App = () => {
  return (
    
    <>

     <BrowserRouter>

     <Navbar />

      <Routes>

      <Route path='/' element={<Home/>} ></Route>
      <Route path='/Register' element={<Register/>} ></Route>
      <Route path='/Registerlist' element={<Registerlist/>} ></Route>

      </Routes>

     </BrowserRouter>
    
    
    </>


  )
}

export default App