
const mongoose = require("mongoose");

const users_Model = mongoose.Schema(

    {

        UserName: {
            type: String,
            required: [true, "User name must enter"],

        },

        UserEmail: {
            type: String,
            required: [true, "User Email must there"]
        },

        UserPassword: {
            type: String,
            required: [true, "User Password must there"]
        },



    }

)


module.exports = mongoose.model("Users", users_Model)

