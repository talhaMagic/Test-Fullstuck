const users = require("../Model/users");
const bcrypt = require("bcrypt");
const fetch = require("node-fetch");  // Ensure you have node-fetch or a similar library if you're using fetch

// @GET METHOD
// HTTP API http://localhost:5000/Register
function UserRegisterpage(req, res) {
    return res.status(200).send("This is the user registration page.");
}

// @POST METHOD
// HTTP API http://localhost:5000/Register
async function UserRegistercreate(req, res) {
    try {
        const { username, useremail, userpassword } = req.body;

        const usernameRegex = /^[a-zA-Z0-9_-]{3,20}$/;
        
        
        if (!usernameRegex.test(username)) {
            return res.status(400).send({ error: "Username must contain only letters, numbers, hyphens, or underscores." });
        }

        
        const existingUser = await users.findOne({ UserName: username.toLowerCase() });
        if (existingUser) {
            return res.status(400).send({ error: "Username already exists. Please choose a different one." });
        }

        // Hash the password 
        const hashpassword = await bcrypt.hash(userpassword, 15);

        
        const newUser = await users.create({
            UserName: username.toLowerCase(),
            UserEmail: useremail,
            UserPassword: hashpassword,
        });

        
        const externalApiData = {
            username: newUser.UserName,
            useremail: newUser.UserEmail,
            userpassword: userpassword,  
        };

        // Send sanitized data to the external API
        const apiResponse = await fetch("https://6732ed192a1b1a4ae111545a.mockapi.io/Usercruddata", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(externalApiData),
        });

        if (apiResponse.ok) {
            return res.status(201).send({ message: "User registered successfully and data sent to external API.", data: externalApiData });
        } else {
            return res.status(apiResponse.status).send({ error: "Failed to send data to external API." });
        }

    } catch (error) {
        console.error(error);
        return res.status(500).send({ error: "Server internal error. Please try again later." });
    }
}

// METHOD -- DELETE 
// API http://localhost:5000/Register/:UserName
//des:  delete single role

async function deleteRole(req,res){
    
    console.log(req.params.UserName);

    const deleterole = await users.deleteOne({UserName:req.params.UserName})

    return res.send({"error" : "Delete secuessfully"});
}

// METHOD -- PU 
// API http://localhost:5000/role/:rolename
//des:  Update single role

async function update(req,res){
    const updateUserName = req.params.UserName;
    
    const User_old_data = await users.findOne({UserName:updateUserName})

    if(User_old_data){

        const { username, useremail, userpassword } = req.body;

        const updateUsers = await users.updateOne( 
    
            { 
                UserName    :  updateUserName
            } 
            
            ,
            
            { 
                $set :  {
                    "UserName": username.toLowerCase(),
                    "UserEmail": useremail,
                    "UserPassword" : userpassword,
                } 
            } 
            
            
        )



        return res.send({"data":req.body})
    }else{
        return res.send({"error":"not found"})
    }

}



module.exports = { UserRegisterpage, UserRegistercreate,deleteRole,update};
